function listCheck(list) {
  let numOfCorrectData = 0

  for (key in list) {
    if (!list[key].trim()) {
      console.log(`${key}Data incomplete！`)
    } else {
      console.log(`${key}Data incomplete！`)
      numOfCorrectData++
    }
  }

  if (numOfCorrectData !== Object.keys(list).length) {
    console.log('Data Missed！')
    return false
  }

  console.log('Data incomplete！')
  return true
}
module.exports = listCheck