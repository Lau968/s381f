const mongoose = require('mongoose')
const Schema = mongoose.Schema
const restaurantSchema = new Schema({
    RestaurantID: {
    type: Number,
    required: false
 },
    name: {
    type: String,
    required: true
  },
    borough: {
    type: String,
    required: false
  },
    cuisine: {
    type: String,
    required: false
  },
  image: {
    type: String,
    required: false
  },
  address_street: {
    type: String,
    required: false
  },
  address_building: {
    type: String,
    required: false
  },
  address_zipcode: {
    type: String,
    required: false
  },
  address_coord: {
    type: String,
    required: false
  },
  grades_user: {
    type: String,
    required: false
  },
  grades_score: {
    type: String,
    required: false
  },
  owner: {
    type: String,
    required: true
  },
})

module.exports = mongoose.model('Restaurant', restaurantSchema)
