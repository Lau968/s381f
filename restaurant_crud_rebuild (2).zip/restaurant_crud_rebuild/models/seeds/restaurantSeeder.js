const mongoose = require('mongoose')
const User = require('../user')
const Restaurant = require('../restaurant')
const UserList = require('./user')
const restaurantList = require('./restaurant')
const bcrypt = require('bcryptjs')

mongoose.connect('mongodb://localhost/restaurant_list', { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true })

const db = mongoose.connection

db.on('error', () => {
  console.log('mongodb error！')
})

db.once('open', () => {
  console.log('mongodb connected！')

  
  const users = []
  for (let i = 0; i < UserList.users.length; i++) {
    const newUser = new User(UserList.users[i])
    bcrypt.genSalt(10, (err, salt) => {
      bcrypt.hash(newUser.password, salt, (err, hash) => {
        if (err) throw err
        newUser.password = hash
        newUser.save()
      })
    })
    users.push(newUser)
  }


  for (let i = 0; i < 3; i++) {
    restaurantList.results[i].userId = users[0]._id
    Restaurant.create(restaurantList.results[i])
  }
  
  for (let i = 3; i < 6; i++) {
    restaurantList.results[i].userId = users[1]._id
    Restaurant.create(restaurantList.results[i])
  }

  console.log('done！')
})
