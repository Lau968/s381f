// routes/restaurant_routes.js
const express = require('express')
const router = express.Router()
const Restaurant = require('../models/restaurant')

// restaurants first page
router.get('/', (req, res) => {
  res.redirect('/restaurants')
})

// 設定 /restaurants route
module.exports = router