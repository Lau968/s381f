const express = require('express')
const router = express.Router()
const Restaurant = require('../models/restaurant')
const listCheck = require('../checkNewList')

const { authenticated } = require('../config/auth')

// Read 取得所有表單 或 指定的排列
// Query String不只可以從input得到，用指定的網址也能讀取到 (課文U41)
// 有空閒回來試著將搜索、排序功能合併
router.get('/', authenticated, (req, res) => {
  const search_order = req.query.search_order
  Restaurant.find({ userId: req.user._id })
    .sort(search_order)
    .lean()
    .exec((err, restaurants) => {
      if (err) return console.error(err)
      return res.render('index', { restaurants })
    })
})

// 取得搜索項目
router.get('/search', authenticated, (req, res) => {
  const word = req.query.keyword
  Restaurant.find({
    userId: req.user._id,
    $or: [
      { 'name': { "$regex": word.toString(), "$options": "i" } },
      { 'name_en': { "$regex": word.toString(), "$options": "i" } },
      { 'category': { "$regex": word.toString(), "$options": "i" } },
    ]
  }).lean()
    .exec((err, restaurants) => {
      if (err) return console.error(err)
      res.render('index', { restaurants, keyword: word })
    })
})

// create
router.get('/new', authenticated, (req, res) => {
  res.render('new')
})

router.post('/', authenticated, (req, res) => {
  const data = req.body
  console.log(data)
  if (listCheck(req.body)) {
    console.log('Save Restaurant Date')
    const restaurant = new Restaurant({
      restaurant_id: req.body.restaurant_id,
      name: req.body.name,
      borough: req.body.borough,
      cuisine: req.body.cuisine,
      photo: req.body.photo,
      address_street: req.body.address_street,
      address_building: req.body.address_building,
      address_zipcode: req.body.address_zipcode,
      address_coord: req.body.address_coord,
      grades_user: req.body.grades_user,
      grades_score: req.body.grades_score,
      owner: req.body.owner,
    })
    restaurant.save(err => {
      if (err) return console.error(err)
      return res.redirect('/')
    })
  } else {
    console.log('direct_to/restaurants/new')
    const result = listCheck(req.body)
    return res.render('new', { result: !result, data })
  }
})

// Read
router.get('/:id', authenticated, (req, res) => {
  Restaurant.findOne({ _id: req.params.id, userId: req.user._id })
    .lean()
    .exec((err, restaurant) => {
      if (err) return console.error(err)
      return res.render('show', { list: restaurant })
    })
})

// Update
router.get('/:id/edit', authenticated, (req, res) => {
  Restaurant.findOne({ _id: req.params.id, userId: req.user._id })
    .lean()
    .exec((err, restaurant) => {
      if (err) return console.error(err)
      return res.render('edit', { list: restaurant })
    })
})

// Update 
router.put('/:id/edit', authenticated, (req, res) => {
  Restaurant.findOne({ _id: req.params.id, userId: req.user._id }, (err, data) => {
    if (err) return console.error(err)
    Object.assign(data, req.body)
    data.save(err => {
      if (err) return console.error(err)
      return res.redirect(`/restaurants/${req.params.id}`)
    })
  })
})

// Delete
router.delete('/:id/delete', authenticated, (req, res) => {
  Restaurant.findOne({ _id: req.params.id, userId: req.user._id }, (err, data) => {
    if (err) return console.error(err)
    data.remove(err => {
      if (err) return console.error(err)
      return res.redirect('/')
    })
  })
})

// set/restaurants route
module.exports = router