// routes/user.js
const express = require('express')
const passport = require('passport')
const bcrypt = require('bcryptjs')
const User = require('../models/user')
const router = express.Router()

// login page
router.get('/login', (req, res) => {
  res.render('login')
})

// vaildation for login
router.post('/login', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/',
    failureFlash: req.flash('warning_msg', 'incorect ID or Password'),
    failureRedirect: '/users/login'
  })(req, res, next)
})


// logout
router.get('/logout', (req, res) => {
  req.logout()
  req.flash('success_msg', '你已經成功登出')
  res.redirect('/users/login')
})

module.exports = router
